const binding = require('./binding')

exports.sendApdu = binding.sendApdu
