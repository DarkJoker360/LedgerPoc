#include <assert.h>
#include <bare.h>
#include <js.h>
#include <utf.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

#define MAX_PACKET_SIZE 64
#define CHANNEL_ID 0x0101
#define TAG 0x05

static void write_u16_be(uint8_t *buf, uint16_t value) {
  buf[0] = (value >> 8) & 0xff;
  buf[1] = value & 0xff;
}

// int fd, const uint8_t *data, size_t total_len, size_t *out_len
static js_value_t *
bare_send_apdu_frame(js_env_t *env, js_callback_info_t *info) {
  int err;

  size_t argc = 2;
  js_value_t *argv[2];
  js_value_t *this_arg;
  void *data_ptr;

  err = js_get_callback_info(env, info, &argc, argv, &this_arg, &data_ptr);
  if (err < 0 || argc < 2) return NULL;

  // === Parse args ===
  int32_t fd;
  err = js_get_value_int32(env, argv[0], &fd);
  if (err < 0) return NULL;

  uint8_t *data = NULL;
  size_t total_len = 0;
  err = js_get_arraybuffer_info(env, argv[1], (void **)&data, &total_len);
  if (err < 0) return NULL;

  // === Constants ===
  uint16_t channel_id = CHANNEL_ID;
  uint8_t tag = TAG;

  size_t offset = 0;
  uint16_t seq = 0;

  // === First packet ===
  size_t first_payload_len = (total_len > (MAX_PACKET_SIZE - 7)) ? (MAX_PACKET_SIZE - 7) : total_len;
  uint8_t first[MAX_PACKET_SIZE] = {0};

  write_u16_be(first, channel_id);
  first[2] = tag;
  write_u16_be(first + 3, seq);
  write_u16_be(first + 5, (uint16_t)total_len);
  memcpy(first + 7, data, first_payload_len);

  if (write(fd, first, MAX_PACKET_SIZE) != MAX_PACKET_SIZE) {
    perror("write (first)");
    return NULL;
  }

  offset += first_payload_len;
  seq++;

  // === Following packets ===
  while (offset < total_len) {
    size_t chunk = (total_len - offset > (MAX_PACKET_SIZE - 5)) ? (MAX_PACKET_SIZE - 5) : (total_len - offset);
    uint8_t pkt[MAX_PACKET_SIZE] = {0};

    write_u16_be(pkt, channel_id);
    pkt[2] = tag;
    write_u16_be(pkt + 3, seq);
    memcpy(pkt + 5, data + offset, chunk);

    if (write(fd, pkt, MAX_PACKET_SIZE) != MAX_PACKET_SIZE) {
      perror("write (following)");
      return NULL;
    }

    offset += chunk;
    seq++;
  }

  // === Read Response ===
  uint8_t buffer[MAX_PACKET_SIZE];
  size_t resp_size = 0;
  size_t resp_alloc = 256;
  uint8_t *resp_data = malloc(resp_alloc);
  if (!resp_data) {
    perror("malloc");
    return NULL;
  }

  uint16_t read_seq = 0;
  int remaining = -1;

  while (1) {
    ssize_t r = read(fd, buffer, MAX_PACKET_SIZE);
    if (r <= 0) {
      perror("read");
      free(resp_data);
      return NULL;
    }

    uint8_t rtag = buffer[2];
    uint16_t rseq = (buffer[3] << 8) | buffer[4];

    if (rtag != tag || rseq != read_seq) {
      fprintf(stderr, "response framing mismatch\n");
      free(resp_data);
      return NULL;
    }

    size_t data_offset = (read_seq == 0) ? 7 : 5;
    size_t data_len = r - data_offset;

    if (read_seq == 0) {
      remaining = (buffer[5] << 8) | buffer[6];
    }

    if ((resp_size + data_len) > resp_alloc) {
      resp_alloc *= 2;
      uint8_t *new_data = realloc(resp_data, resp_alloc);
      if (!new_data) {
        perror("realloc");
        free(resp_data);
        return NULL;
      }
      resp_data = new_data;
    }

    memcpy(resp_data + resp_size, buffer + data_offset, data_len);
    resp_size += data_len;
    read_seq++;

    if (resp_size >= (size_t)remaining) {
      break;
    }
  }

  // === Return as JS Buffer ===
  js_value_t *buf = NULL;
  void *result_data = NULL;

  err = js_create_arraybuffer(env, remaining, &result_data, &buf);
  if (err < 0) {
    free(resp_data);
    return NULL;
  }

  memcpy(result_data, resp_data, remaining);
  free(resp_data);

  return buf;
}

static js_value_t *
bare_addon_exports(js_env_t *env, js_value_t *exports) {
  int err;

#define V(name, fn) \
  { \
    js_value_t *val; \
    err = js_create_function(env, name, -1, fn, NULL, &val); \
    assert(err == 0); \
    err = js_set_named_property(env, exports, name, val); \
    assert(err == 0); \
  }

  V("sendApdu", bare_send_apdu_frame)
#undef V

  return exports;
}

BARE_MODULE(bare_addon, bare_addon_exports)
